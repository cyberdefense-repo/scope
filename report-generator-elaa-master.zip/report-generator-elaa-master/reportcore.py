from ast import Or
import datetime
from lib2to3.pgen2.parse import ParseError
import re
import operator
import collections
import glob
import csv
import json
import sys
import os
import subprocess

# Check if installed then execute pip and install dependencies using subprocess:
try:
    import numpy as np
except ModuleNotFoundError:
    print("Installing numpy module")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'numpy'])

# Check if installed then execute pip and install dependencies using subprocess:
try:
    import pandas as pd
except ModuleNotFoundError:
    print("Installing pandas module")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pandas'])

# Check if installed then execute pip and install dependencies using subprocess:
try:
    import docx
except ModuleNotFoundError:
    print("Installing python_docx module")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'python_docx'])

# Check if installed then execute pip and install dependencies using subprocess:
try:
    import yaml
except ModuleNotFoundError:
    print("Installing pyyaml module")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyyaml'])

# Check if installed then execute pip and install dependencies using subprocess:
try:
    import tkinter as tk
except ModuleNotFoundError:
    print("Installing tkinter module")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'tk'])

# Check if installed then execute pip and install dependencies using subprocess:
try:
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    print("Installing matplotlib module")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'matplotlib'])

# Finalize dependency install:
reqs = subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'])
installed_packages = [r.decode().split('==')[0] for r in reqs.split()]

import matplotlib.dates as mdates

from docx.enum.style import WD_STYLE_TYPE
from docx.enum.section import WD_SECTION
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.text import WD_BREAK
from docx.shared import Pt
from docx.shared import Inches
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

baseFolder = './Data/'
inputDocument = './Config/MasterTemplateV1.6.docx'
inputAlertAddDoc = './Config/AlertAddendumV1.1.docx'
inputTktAddDoc = './Config/TicketAddendumV1.1.docx'
outputImage = './ingest-chart.png'

####################
# Define functions #
####################

def errorlog(event):
    errorhandle = open(".\error.log", "a+")
    errorhandle.write(event)
    errorhandle.close()


def process_incidents(incidentFile,baseFolder):
    debug = False
    #print("Processing incidents file.")
    
    # Import csv file into a pandas dataframe
    csvFileDf = pd.read_csv(incidentFile)
    #print(csvFileDf)
    
    # count total tickets
    totalTickets = len(csvFileDf.index)
    #print('Total tickets: ' + str(totalTickets))

    # Clean up and extract text
    alertDf = csvFileDf['short_description'].str.replace('Splunk Alert:\s|Search Alert:\s|Search Results:\s|PagerDuty: Search Alert:\s', '', regex=True)
    alertDf = pd.concat([alertDf, alertDf.str.extract('^.*?\s(?P<alertId>[A-Z]{3}\d{3}|\w{3,})\s\((?P<alertSev>[Ss][Ee][Vv]\s\d)\)\s-\s(?P<alertDesc>.*)$')], axis=1)
    #print(alertDf)

    # Count total of Severity levels
    sevDf = alertDf['alertSev'].value_counts().rename_axis('alertSev').reset_index(name='count')

    # Get uniques and counts
    alertDf = alertDf.value_counts(['short_description','alertId','alertSev','alertDesc']).reset_index(name='count')
    #print(alertDf)

    if debug:
        print("DEBUG (process_incidents): alertId={0} alertSev={1} alertDesc={2}".format(alertId,alertSev,alertDesc))
    
    return(totalTickets,alertDf,sevDf)
    

def insert_ticket_stats(docObj,tableStyle,totalTickets,alertDf,sevDf):
    ## monthly ticket highlights ##
    print("Adding Monthly Ticket Highlights")
    insert_table_heading(docObj,'Monthly Ticket Highlights',2)
    
    # Create DataFrame from csvdata
    csvDataFrame = pd.DataFrame([['Unique Alert Name','Triggered Count','% of Total']], columns=['short_description','count', 'pctTotal'])
    #print(csvDataFrame)

    # Write data to DataFrame joining on column names
    csvDataFrame = pd.concat([csvDataFrame, alertDf], join='inner', ignore_index=True)
    #print(csvDataFrame)

    # Update pctTotal field
    csvDataFrame.loc[1:, 'pctTotal'] = ((csvDataFrame.loc[1:, 'count']/totalTickets).apply('{:.0%}'.format))
    csvDataFrame.loc[0, 'pctTotal'] = '% of Total'
    #print(csvDataFrame)

    # Add Totals row
    csvDataFrame.loc[len(csvDataFrame.index)] = ['Total', totalTickets, '100%']
    #print(csvDataFrame)

    # Insert table into docx
    insert_docx_table(docObj,tableStyle,csvDataFrame)
    
    ## Ticket Severity Overview ##
    print("Adding Ticket Security Overview")
    insert_table_heading(docObj,'Ticket Severity Overview',2)
    labelsDf = pd.DataFrame(['Sev 1','Sev 2','Sev 3','Sev 4'], columns=['alertSev'])
    #sizes = []
    
    # Create DataFrame and add labels
    csvDfSev = pd.DataFrame([['Ticket Severity','Triggered Count','% of Total']], columns=['alertSev','count', 'pctTotal'])
    #csvDfSev = csvDfSev.append(labelsDf, ignore_index=True)
    csvDfSev = pd.concat([csvDfSev, pd.DataFrame(labelsDf)], ignore_index=True)

    # Set NaN to 0
    csvDfSev.fillna({'count':0, 'pctTotal':0}, inplace=True)
    #print(csvDfSev)

    # Write data to DataFrame
    csvDfSev.set_index('alertSev', inplace=True)
    csvDfSev.update(sevDf.set_index('alertSev'))
    csvDfSev.reset_index(inplace = True)
    #print(csvDfSev)

    # Convert count values to Int
    csvDfSev.loc[1:,'count'] = csvDfSev.loc[1:, 'count'].astype(int)
    #print(csvDfSev)

    # Update pctTotal field
    csvDfSev.loc[1:, 'pctTotal'] = ((csvDfSev.loc[1:, 'count']/totalTickets).apply('{:.0%}'.format))
    #print(csvDfSev)

    # Add Totals row
    csvDfSev.loc[len(csvDfSev.index)] = ['Total', totalTickets, '100%']
    #print(csvDfSev)

    #insert_chart_pie(docObj,labels,sizes,'./ticketPie.png',4,4)
    
    # Write table to docx
    insert_docx_table(docObj,tableStyle,csvDfSev)


def process_stats_files(alertIdDf):
    print("Processing alert ID stats files.")
    for alert in alertIdDf['alertId']:
        print("Opening alert file {0}".format(alert))


def insert_chart_pie(docObj,labels,sizes,pieFile,pieWidth,pieHeight):
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    #explode = (0, 0.1, 0, 0)  # only "explode" the 2nd slice

    fig1, ax1 = plt.subplots()
    ax1.pie(sizes, labels=labels, autopct='%1.1f%%', shadow=False, startangle=0)
    ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

    plt.savefig(pieFile)
    docObj.add_picture(pieFile,width=Inches(pieWidth), height=Inches(pieHeight))


def insert_chart_ingest(docObj,baseFolder,globPattern,outputImage,chartHeight,chartWidth):
    curSection = docObj.sections[len(docObj.sections) - 1]
    curSection.top_margin = Inches(0.5)
    curSection.bottom_margin = Inches(0.5)

    print('Processing Monthly Ingest Data')
    wildfile = baseFolder+"/*{0}*.csv".format(globPattern)
    foundfile = glob.glob(wildfile)
    if foundfile and len(foundfile) == 1:
        # Import csv file into a pandas dataframe
        csvDataTableDf = pd.read_csv(foundfile[0], index_col=0)
        #print(csvDataTableDf)

        # Get total ingest
        totalGb = str(csvDataTableDf['GB'].sum().round(2))
        dailyAvg = str((csvDataTableDf['GB'].sum()/len(csvDataTableDf.index)).round(2))
        #print(totalGb)

        # Plot the bar graph
        csvDataTableDf.plot(kind='bar', legend=False, align='center', width=0.8, figsize=(chartWidth,chartHeight))
    else:
        errorlog("Error locating ingest file for insert_chart_ingest.\nFile Glob result was: {0}\n".format(foundfile))
        return

    #print("dateLabels: {0}  dateHeight: {1}\n".format(dateLabels,dateHeight))

     # Add labels and title
    plt.title("Daily Index Volume")
    plt.xlabel("Date", fontweight='bold')
    plt.ylabel("GB", fontweight='bold')
 
    # Modify axis format
    plt.fmt_xdata = mdates.DateFormatter('%m/%d/%Y')
    plt.xticks(rotation=90)
    plt.tick_params(axis='x',labelsize=6)
    # fix x axis clipping of label
    plt.gcf().subplots_adjust(bottom=0.25)
    
    # Add Trendline
    coefficients, residuals, _, _, _ = np.polyfit(range(len(csvDataTableDf.index)),csvDataTableDf,1,full=True)
    # Get slope of line to determine color then plot
    if coefficients[0] <= 0:
        plt.plot([coefficients[0]*x + coefficients[1] for x in range(len(csvDataTableDf))], color="green")
    else:
        plt.plot([coefficients[0]*x + coefficients[1] for x in range(len(csvDataTableDf))], color="red")

    # Use only for debugging charts
    #plt.show()
    
    # Save the chart and add to Word document
    plt.savefig(outputImage)
    docObj.add_picture(outputImage,width=Inches(chartWidth), height=Inches(chartHeight))
    
    return(totalGb, dailyAvg)


def insert_alert_csv(docObj,tableStyle,baseFolder,alertDf,inputAlertAddDoc,alertAddFlag):
    #print("Adding Alert Ticket Detail Sections.")
    # add wildfile path column
    alertDf['wildfile'] = baseFolder + '/*?' + alertDf['alertId'] + '?(' + alertDf['alertSev'].str.replace('\s|_','?', regex=True) + ')?*.csv'
    print("Processing alert ID stats files\n")
        
    # Write data to docx
    for i in range(alertDf.shape[0]):
        #print(alertDf.loc[i,'alertId'],alertDf.loc[i,'alertSev'],alertDf.loc[i,'alertDesc'],alertDf.loc[i,'wildfile'])
        foundfile = glob.glob(alertDf.loc[i,'wildfile'])
        #print(foundfile)
        #process_stats_files(foundfile)
        if foundfile and len(foundfile) == 1:
            print("Processing filename: {0}".format(foundfile))
            print("{0} {1} - {2}".format(alertDf.loc[i,'alertId'],alertDf.loc[i,'alertSev'],alertDf.loc[i,'alertDesc']))
            insert_table_heading(docObj,"{0} ({1}) - {2}".format(alertDf.loc[i,'alertId'],alertDf.loc[i,'alertSev'],alertDf.loc[i,'alertDesc']),2)
            insert_csv_table(docObj,foundfile,alertDf.loc[i,'alertSev'],alertDf.loc[i,'alertId'],alertDf.loc[i,'alertDesc'],inputAlertAddDoc,alertAddFlag)
            insert_findings_paragraph(docObj,'{{ INSERT ANALYST NARRATIVE HERE }}')
            insert_blank_row(docObj)
            print("Completed processing: {0} {1} - {2}\n".format(alertDf.loc[i,'alertId'],alertDf.loc[i,'alertSev'],alertDf.loc[i,'alertDesc']))
        else:
            errorlog("Error processing file for {0} {1}\n".format(alertDf.loc[i,'alertId'],alertDf.loc[i,'alertSev']))
            print("Error processing file for {0} {1}".format(alertDf.loc[i,'alertId'],alertDf.loc[i,'alertSev']))
            print("File glob result was: {0}\n".format(foundfile))

def insert_table_heading(docObj,tablename,hlevel):
    docObj.add_heading(tablename,level=hlevel)

def insert_csv_table(docObj,csvfile, *args):
    tableStyle = 'Grid Table 4 Accent 5'
    #print("DEBUG (insert_csv_table) - csvfile: {0}".format(csvfile))
    if len(args) == 2:
        print("ARGS0: {0}\nARGS1: {1}\n".format(args[0],args[1]))
        heightOverride = args[0]
        widthOverride = args[1]
    elif len(args) == 1:
        widthOverride = args[1]

    if len(args) == 5:
        alertSev = args[0]
        alertId = args[1]
        alertDesc = args[2]
        inputAlertAddDoc = args[3]
        alertAddFlag = args[4]
    else:
        alertSev = ''
    
    if not isinstance(csvfile,list):
        csvfile = [csvfile]
    
    # Create DataFrame from csvfile
    if alertSev == 'Sev 3':
        try:      
            csvDataFrame = pd.read_csv(csvfile[0], nrows=26, header=None)
        except FileNotFoundError:
            print('Could not open file: ' + csvfile[0] + '\n')
            errorlog('Could not open file: ' + csvfile[0] + '\n')
            exit()
        except pd.errors.ParserError:
            print('Could not parse csv data file: ' + baseFolder + arg + '\n' + 'Please check the file for errors')
            errorlog('Could not parse csv data file: ' + baseFolder + arg + '\n' + 'Please check the file for errors')
            exit()
        csvDf = pd.read_csv(csvfile[0], header=None)
        if len(csvDf) > 25 and alertAddFlag:
            # Write remaining rows to Alert Addendum Report
            print('Creating and writing Alert Addendum_' + alertId + ' - ' + alertDesc)
            # Check if csv file is larger than 25 rows
            alertAddDoc = docx.Document(inputAlertAddDoc)
            replace_run_text(alertAddDoc, 'alertName', alertId + ' - ' + alertDesc)
            #alertAddDoc.add_page_break()
            alertAddDoc.add_heading('Purpose',level=1)
            alertAddDoc.add_paragraph('The monthly report limits Severity 3 tables to 25 rows. This report captures the actual number of alerts which is too large to fit in the monthly report. For analysis and recommendations, please review the section in the main report which is applicable to the specific alert.')
            insert_table_heading(alertAddDoc,"{0} ({1}) - {2}".format(alertId,alertSev,alertDesc),2)
            #csvDf = pd.read_csv(csvfile[0], header=None)
            insert_docx_table(alertAddDoc,tableStyle,csvDf)
            try:
                a = open('Alert Addendum_' + alertId + ' - ' + alertDesc + '.docx','w')
                print('Saving Alert Addendum_' + alertId + ' - ' + alertDesc + '.docx') 
                a.close()
                alertAddDoc.save('Alert Addendum_' + alertId + ' - ' + alertDesc + '.docx')
            except IOError:
                print('Could not save Alert Addendum_' + alertId + ' - ' + alertDesc + '.docx...The file is open\n')
                errorlog('Could not save Alert Addendum_' + alertId + ' - ' + alertDesc + '.docx...The file is open\n')
                exit()
    else:
        try:
            csvDataFrame = pd.read_csv(csvfile[0], header=None)
            #print(csvDataFrame)
        except FileNotFoundError:
            print('Could not open file: ' + csvfile[0] + '\n')
            errorlog('Could not open file: ' + csvfile[0] + '\n')
            exit()
        except pd.errors.ParserError:
            print('Could not parse csv data file: ' + baseFolder + arg + '\n' + 'Please check the file for errors')
            errorlog('Could not parse csv data file: ' + baseFolder + arg + '\n' + 'Please check the file for errors')
            exit()

    # Insert DataFrame into docx table
    csvDf = pd.read_csv(csvfile[0], header=None) # get total rows in csv file
    if alertSev == 'Sev 3' and len(csvDf) > 25 and alertAddFlag:
        insert_docx_table(docObj,tableStyle,csvDataFrame)
        insert_findings_paragraph(docObj,'This is a representative table and has more than 25 rows. Due to space management in this document, an alert addendum with the full table is included as a separate document with this report. Please see the associated Alert Addendum.')
    else:
        insert_docx_table(docObj,tableStyle,csvDataFrame)

def insert_csv_tables(docObj,baseFolder, *args):
    tableStyle = 'Grid Table 4 Accent 5'
    #print("DEBUG (insert_csv_table) - csvfile: {0}".format(csvfile))

    # debug number of arguments
    #print(len(args))

    # get number of rows
    if len(args) % 2 == 1:
        row_count = (len(args) + 1) // 2
    else:
        row_count = len(args) // 2
    
    # debug number of rows
    #print(row_count)
    
    # Create container table and add to document
    container_table = docObj.add_table(row_count, 2)
    #paragraph.paragraph_format.space_before = Pt(0)
    
    # create dataframes from args then write to docx
    curRow = 0
    curCell = 0
    try:      
        for arg in args:
            # read in csv
            tempDF = pd.read_csv(baseFolder + arg, header=None)
            #print(tempDF)
            # add title to table with applied style
            cell = container_table.rows[curRow].cells[curCell]
            paragraph = cell.paragraphs[0]
            paragraph.style = docObj.styles['Heading 4']
            paragraph.paragraph_format.space_before = Pt(6)
            run = paragraph.add_run(os.path.splitext(arg)[0])
            #font = run.font
            #runStyle = run.style
            #runStyle.name = 'Heading 4'
            #font.bold = True
            #font.name = 'Calibri'
            #font.size = Pt(14)
            #paragraph = container_table.rows[curRow].cells[curCell].add_paragraph(text=arg, style='Heading 4')
            #paragraph.paragraph_format.space_before = Pt(0)
            #container_table.rows[curRow].cells[curCell].vertical_alignment = WD_ALIGN_VERTICAL.TOP
            # Insert DataFrame into docx table
            insert_docx_tables(docObj,tableStyle,container_table,tempDF,curRow,curCell,arg)
            #print(args[arg])
            curCell += 1 # get correct cell since two columns only 0 or 1
            if curCell > 1:
                curCell = 0
                curRow += 1
    except FileNotFoundError:
        print('Could not open file: ' + baseFolder + arg + '\n')
        errorlog('Could not open file: ' + baseFolder + arg + '\n')
        exit()
    except pd.errors.ParserError:
        print('Could not parse csv data file: ' + baseFolder + arg + '\n' + 'Please check the file for errors')
        errorlog('Could not parse csv data file: ' + baseFolder + arg + '\n' + 'Please check the file for errors')
        exit()
    

def insert_docx_table(docObj,tableStyle,csvdata):
    debug = False
    
    # Create DataFrame from csvdata
    csvDataFrame = pd.DataFrame(csvdata)
    #print("DEBUG (insert_docx_table): numcols={0}".format(numcols))
    
    # Create docx table
    docxTable = docObj.add_table(csvDataFrame.shape[0], csvDataFrame.shape[1], style=tableStyle) # Using Pandas DataFrame
    table_cells = docxTable._cells

    # Write the DataFrame to docx
    #print('Writing Data to Docx\n')
    for i in range(csvDataFrame.shape[0]):
        row_cells = table_cells[i*csvDataFrame.shape[1]:(i+1)*csvDataFrame.shape[1]]
        update_progress(i,csvDataFrame.shape[0], status='Writing Data to Docx')
        for j in range(csvDataFrame.shape[1]):
            row_cells[j].text = str(csvDataFrame.values[i, j])
        update_progress(csvDataFrame.shape[0],csvDataFrame.shape[0], status='Complete                             ')
    print('\n')
    
    set_repeat_table_header(docxTable.rows[0])

def insert_docx_tables(docObj,tableStyle,container_table,csvDataFrame, curRow,curCell,arg):
    debug = False
        
    # Create docx table
    docxTable = container_table.rows[curRow].cells[curCell].add_table(csvDataFrame.shape[0], csvDataFrame.shape[1]) # Using Pandas DataFrame
    docxTable.style = 'Grid Table 4 Accent 5' # apply gridline and banded row style
    table_cells = docxTable._cells
    
    #if curCell == 1:
        #docxTable.alignment = WD_TABLE_ALIGNMENT.RIGHT
    
    # Write the DataFrame to docx
    #print('Writing Data to Docx\n')
    for i in range(csvDataFrame.shape[0]):
        row_cells = table_cells[i*csvDataFrame.shape[1]:(i+1)*csvDataFrame.shape[1]]
        update_progress(i,csvDataFrame.shape[0], status='Writing Data to Docx')
        for j in range(csvDataFrame.shape[1]):
            row_cells[j].text = str(csvDataFrame.values[i, j])
        update_progress(csvDataFrame.shape[0],csvDataFrame.shape[0], status='Complete                             ')
    print('\n')
    
    # set width of cell tables to allow for gap in between
    for i in (0,1):
        for cell in docxTable.columns[i].cells:
            cell.width = Inches(1.6)

    set_repeat_table_header(docxTable.rows[0])
   
    #print('Current Row ' + str(curRow) + '  ' + 'Current Cell ' + str(curCell))
    #print('\n')

def set_repeat_table_header(row):
    """ set repeat table row on every new page
    """
    tr = row._tr
    trPr = tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), "true")
    trPr.append(tblHeader)
    return row

def insert_ticket_summary(docObj,incidentFile,baseFolder):
    tableStyle = 'Grid Table 4 Accent 5'
    (totalTickets,alertDf,sevDf) = process_incidents(incidentFile,baseFolder)
    insert_ticket_stats(docObj,tableStyle,totalTickets,alertDf,sevDf)

def insert_ticket_details(docObj,incidentFile,baseFolder,inputAlertAddDoc,alertAddFlag):
    tableStyle = 'Grid Table 4 Accent 5'
    (totalTickets,alertDf,sevDf) = process_incidents(incidentFile,baseFolder)
    #process_stats_files(alertDf)
    insert_alert_csv(docObj,tableStyle,baseFolder,alertDf,inputAlertAddDoc,alertAddFlag)

def insert_ticket_addendum(custName,incidentFile,baseFolder,inputTktAddDoc,prevMonth,tktAddFlag):
    if tktAddFlag:
        try:
            tableStyle = 'Grid Table 4 Accent 5'
            print("Processing Ticket Addendum.")
            
            # Import csv file into a pandas dataframe
            csvFileDf = pd.read_csv(incidentFile)
            #print(csvFileDf)
            
            # Create DataFrame from csvdata
            csvDataFrame = pd.DataFrame([['Inc#','Date','Time Open in hh:mm:ss','Alert Name']], columns=['number','sys_created_on','calendar_duration','short_description'])
            #print(csvDataFrame)

            # Merge columns from DataFrames into csvDataFrame
            csvDataFrame = pd.concat([csvDataFrame, csvFileDf], join="inner")
            csvDataFrame.reset_index(drop=True,inplace=True)
            #print(csvDataFrame)

            # Clean up text
            csvDataFrame.loc[:,'short_description'] = csvDataFrame.loc[:,'short_description'].str.replace('Splunk Alert:\s|Search Alert:\s|Search Results:\s|^.*?\s', '', regex=True)
            csvDataFrame.loc[:,'short_description'] = csvDataFrame.loc[:,'short_description'].str.replace('^.*?\s', '', regex=True)
            csvDataFrame.loc[:,'sys_created_on'] = csvDataFrame.loc[:,'sys_created_on'].str.replace('\s\d{1,}:\d{1,}:\d{1,}', '', regex=True)
            #print(csvDataFrame)

            # Convert calendar_duration to hh:mm:ss
            csvDataFrame.loc[1:,'calendar_duration'] = csvDataFrame.loc[1:,'calendar_duration'].astype('float64')
            csvDataFrame.loc[1:,'calendar_duration'] = pd.to_datetime(csvDataFrame.loc[1:,'calendar_duration'], unit='s').dt.strftime("%H:%M:%S") 
            #print(csvDataFrame)

        except KeyError:
            print('Could not open the incident.csv successfully for Ticket Addendum processing. Columns are missing. It should contain sys_created_on, short_description, calendar_duration and number.\n')
            errorlog('Could not open the incident.csv successfully for Ticket Addendum processing. Columns are missing. It should contain sys_created_on, short_description, calendar_duration and number.\n')
            exit()

        # Write table to docx and save
        print('Creating and writing Ticket Addendum report')
        # Create document object
        alertTktDoc = docx.Document(inputTktAddDoc)
        replace_run_text(alertTktDoc, '{{CUSTOMER NAME}}', custName)
        replace_run_text(alertTktDoc, '{{Month Year}}', prevMonth)
        insert_docx_table(alertTktDoc,tableStyle,csvDataFrame)
        try:
            a = open('./' + custName + ' Monthly Report (' + get_previous_month() + ') - Ticket Addendum.docx','w')
            print('Saving Ticket Addendum report') 
            a.close()
            alertTktDoc.save('./' + custName + ' Monthly Report (' + get_previous_month() + ') - Ticket Addendum.docx')
        except IOError:
            print('Could not save "' + custName + ' Monthly Report (' + get_previous_month() + ') - Ticket Addendum.docx' + '" The file is open\n')
            errorlog('Could not save "' + custName + ' Monthly Report (' + get_previous_month() + ') - Ticket Addendum.docx' + '" The file is open\n')
            exit()
        print('Completed Processing Ticket Addendum report\n')

def insert_findings_paragraph(docObj,narrative):
    docObj.add_paragraph()
    findingsTable = docObj.add_table(rows=1,cols=1,style='Table Grid')
    findingsCell = findingsTable.cell(0,0)
    findingsCell.text = str(narrative)
    findingsCell.paragraphs[0].runs[0].font.name = 'New Times Roman'
    findingsCell.paragraphs[0].runs[0].font.size = Pt(12)
    findingsCell.paragraphs[0].runs[0].font.bold = True
    findingsCell.paragraphs[0].runs[0].font.italic = True

def insert_blank_row(docObj):
    p = docObj.add_paragraph()
    run = p.add_run()
    run.add_break(break_type=WD_BREAK.PAGE)

def insert_ingest_calendar(docObj,baseFolder,globPattern):
    tableStyle = 'Grid Table 4 Accent 5'
    wildfile = baseFolder+"/*{0}*.csv".format(globPattern)
    dateLabels = []
    dateGBs = []
    foundfile = glob.glob(wildfile)
    if foundfile and len(foundfile) == 1:
        csvhandle = open(foundfile[0], 'r')
        with csvhandle:
            csvDataTable = csv.reader(csvhandle)
            for x in list(csvDataTable)[1:]:
                dateLabels.append(x[0])
                dateGBs.append(float(x[1]))
                #print("date: {0}  height: {1}\n".format(x[0],x[1]))
        build_ingest_calendar(docObj,tableStyle,dateLabels,dateGBs)
    else:
        errorlog("Error locating ingest file for insert_ingest_table.\nFile Glob result was: {0}\n".format(foundfile))
        return

def build_ingest_calendar(docObj,tableStyle,dateLabels,dateGBs, *args):
    docxTable = docObj.add_table(rows=8, cols=7, style=tableStyle)
    docxTable.alignment = WD_TABLE_ALIGNMENT.CENTER

    # merge the heading row
    datee = datetime.datetime.strptime(str(dateLabels[0]), "%m/%d/%Y")
    startCell = docxTable.cell(0,0)
    endCell = docxTable.cell(0,6)
    calendarMonth = startCell.merge(endCell)
    calendarMonth.text = datee.strftime("%B")
    calendarMonth.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    calendarMonth.paragraphs[0].runs[0].font.size = Pt(20)
    
    # add days of the week titles
    docxTable.rows[1].cells[0].text = "Sunday"     
    docxTable.rows[1].cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[0].paragraphs[0].runs[0].font.bold = True     
    docxTable.rows[1].cells[1].text = "Monday"     
    docxTable.rows[1].cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[1].paragraphs[0].runs[0].font.bold = True     
    docxTable.rows[1].cells[2].text = "Tuesday"     
    docxTable.rows[1].cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[2].paragraphs[0].runs[0].font.bold = True     
    docxTable.rows[1].cells[3].text = "Wednesday"     
    docxTable.rows[1].cells[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[3].paragraphs[0].runs[0].font.bold = True     
    docxTable.rows[1].cells[4].text = "Thursday"     
    docxTable.rows[1].cells[4].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[4].paragraphs[0].runs[0].font.bold = True     
    docxTable.rows[1].cells[5].text = "Friday"     
    docxTable.rows[1].cells[5].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[5].paragraphs[0].runs[0].font.bold = True     
    docxTable.rows[1].cells[6].text = "Saturday"     
    docxTable.rows[1].cells[6].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER     
    docxTable.rows[1].cells[6].paragraphs[0].runs[0].font.bold = True
    
    weekRow = 2
    startingWeekdayNum = datee.strftime("%w")
    #print("Starting weekday value: {0}".format(startingWeekdayNum))
    weekCol = int(startingWeekdayNum)
    
    for (calIndex,calDay) in enumerate(dateLabels):
        #print("date: {0}".format(calDay))
        DayOfMonth=calIndex+1
        #print("DayOfMonthIndex: {0}\tDayOfMonth: {1}\tweekRow: {2}\tweekCol: {3}".format(calIndex,DayOfMonth,weekRow,weekCol))
        if weekCol > 6:
            weekCol = 0
            weekRow = weekRow + 1
            #print("advancing a row")
            #print("DayOfMonthIndex: {0}\tDayOfMonth: {1}\tweekRow: {2}\tweekCol: {3}".format(calIndex,DayOfMonth,weekRow,weekCol))
        docxTable.rows[weekRow].cells[weekCol].text = str(DayOfMonth)
        docxTable.rows[weekRow].cells[weekCol].paragraphs[0].runs[0].font.bold = True
        docxTable.rows[weekRow].cells[weekCol].paragraphs[0].runs[0].font.size = Pt(9)
        docxTable.rows[weekRow].cells[weekCol].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
        docxTable.rows[weekRow].cells[weekCol].add_paragraph(text = "\n{:.2f} GB".format(float(dateGBs[calIndex])))
        docxTable.rows[weekRow].cells[weekCol].paragraphs[1].runs[0].font.bold = False
        docxTable.rows[weekRow].cells[weekCol].paragraphs[1].runs[0].font.size = Pt(9)
        docxTable.rows[weekRow].cells[weekCol].paragraphs[1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        weekCol = weekCol + 1

def read_json_file(jsonfile):
    df = pd.read_json(jsonfile)
    normalDf = pd.json_normalize(df['children'])
    jsonDf = normalDf[['name']]
    #print(jsonDf)

    # Remove rows with RPT. ~ is a bitwise not and used in this code to filter the "contains" string
    jsonDf = jsonDf[~jsonDf.name.str.contains('RPT')]

    # Regex text extraction using Pandas .extract function
    alertDf = jsonDf['name'].str.extract('^.*?\s(?P<alertId>[A-Z]{3}\d{3}|\w{3,})\s\((?P<alertSev>[Ss][Ee][Vv]\s\d)\)\s-\s(?P<alertDesc>.*)$')
    #print(alertDf)

    # Pandas .loc Access a group of rows and columns by label(s) or a boolean array.
    # This line determines if row contains BURN-IN and if it does, adds Yes to the corresponding alertBurn Cell
    alertDf.loc[jsonDf['name'].str.contains('BURN-IN'), 'alertBurn'] = 'Yes'

    # Ignore NaN rows
    alertDf = alertDf[alertDf['alertId'].notna()]

    # Sort on AlertId column
    alertDf = alertDf.sort_values(by='alertId')

    # Clean alertBurn column of NaN text
    alertDf['alertBurn'] = alertDf['alertBurn'].fillna('')

    # Add header row
    new_row = pd.DataFrame({'alertId':'Alert ID', 'alertDesc':'Name', 'alertSev':'Severity', 'alertBurn':'BURN-IN'}, index=[0])
    alertDf = pd.concat([new_row, alertDf[:]]).reset_index(drop = True)
    #print(alertDf)

    return(alertDf)

def read_yaml_file(yamlfile, baseFolder):
    yamlobj = []
    #alertCsv = []
    for filename in glob.iglob(f'{baseFolder}/*.yml'):
        yamlhandle = open(filename, 'r')
        with yamlhandle:
            docs = yaml.load_all(yamlhandle, Loader=yaml.FullLoader)
            for doc in docs:
                for k, v in doc.items():
                    if k == 'name':
                        yamlobj.append(v)
                    else:
                        break
    yamlDf = pd.DataFrame(yamlobj)
    yamlDf.columns = ['name']
    
    # Remove rows with RPT. ~ is a bitwise not and used in this code to filter the "contains" string
    yamlDf = yamlDf[~yamlDf.name.str.contains('RPT')]
    #print(yamlDf)

    # Regex text extraction using Pandas .extract function
    alertDf = yamlDf['name'].str.extract('^.*?(?P<alertId>[A-Z]{3}\d{3}|\w{3,})\s\((?P<alertSev>[Ss][Ee][Vv]\s\d)\)\s-\s(?P<alertDesc>.*)$')
    #print(alertDf)

    # Pandas .loc Access a group of rows and columns by label(s) or a boolean array.
    # This line determines if row contains BURN-IN and if it does, adds Yes to the corresponding alertBurn Cell
    alertDf.loc[yamlDf['name'].str.contains('BURN-IN'), 'alertBurn'] = 'Yes'

    # Ignore NaN rows
    alertDf = alertDf[alertDf['alertId'].notna()]

    # Sort on AlertId column
    alertDf = alertDf.sort_values(by='alertId')

    # Clean alertBurn column of NaN text
    alertDf['alertBurn'] = alertDf['alertBurn'].fillna('')

    # Add header row
    new_row = pd.DataFrame({'alertId':'Alert ID', 'alertDesc':'Name', 'alertSev':'Severity', 'alertBurn':'BURN-IN'}, index=[0])
    alertDf = pd.concat([new_row, alertDf[:]]).reset_index(drop = True)
    #print(alertDf)

    return(alertDf)

def read_splunk_csv_file(csvfile):
    # Suppress Pandas default warnings for chained assignments
    pd.options.mode.chained_assignment = None

    # Import csv file into a pandas dataframe
    csvDf = pd.read_csv(csvfile)

    # Remove rows with RPT. ~ is a bitwise not and used in this code to filter the "contains" string
    csvDf = csvDf[~csvDf.title.str.contains('RPT')]

    # Use vectorization and re to extract text
    # Create new DataFrame
    alertDf = pd.DataFrame()

    # Flatten the DataFrame into a one dimensional ndarray.
    alertString = pd.Series(csvDf.title.values.flatten(), name="alertText")
    #print(alertString)

    # Regex text extraction using Pandas .extract function
    alertDf = alertString.str.extract('^.*?\s(?P<alertId>[A-Z]{3}\d{3}|\w{3,})\s\([Ss][Ee][Vv]\s(?P<alertSev>\d)\)\s-\s(?P<alertDesc>.*)$')

    # Pandas .loc Access a group of rows and columns by label(s) or a boolean array.
    # This line determines if row contains BURN-IN and if it does, adds Yes to the corresponding alertBurn Cell
    alertDf.loc[alertString.str.contains('BURN-IN'), 'alertBurn'] = 'Yes'

    # Ignore NaN rows
    alertDf = alertDf[alertDf['alertId'].notna()]

    # Sort on AlertId column
    alertDf = alertDf.sort_values(by='alertId')

    # Clean alertBurn column of NaN text
    alertDf['alertBurn'] = alertDf['alertBurn'].fillna('')

    # Add header row
    new_row = pd.DataFrame({'alertId':'Alert ID', 'alertDesc':'Name', 'alertSev':'Severity', 'alertBurn':'BURN-IN'}, index=[0])
    alertDf = pd.concat([new_row, alertDf[:]]).reset_index(drop = True)

    return(alertDf)       

def insert_active_alerts(docObj,alertfile,baseFolder):
    print('Processing Active Alerts List')
    #process SumoLogic alert list
    if '.json' in alertfile:
        alertCsv = read_json_file(alertfile)
        #for alert in alertObj['children']:
            #if alert['name']:
                #print("json alert name: {0}".format(alert['name']))
                #alertCsv.append(alert['name'])
    # process yaml files
    elif '.yml' in alertfile:
        alertCsv = read_yaml_file(alertfile,baseFolder)
    #process Splunk alert list in REST format
    elif '.csv' in alertfile:
        alertCsv = read_splunk_csv_file(alertfile)
    # filter out any RPT queries
    #alertCsv = [alert for alert in alertCsv if ' RPT ' not in alert]
    #alertCsv = sorted(alertCsv, key=operator.itemgetter(0))
    #tableHeader = ['Alert ID','Name','Severity','Burn-In']
    #alertCsv.insert(0,tableHeader)
    tableStyle = 'Grid Table 4 Accent 5'
    insert_docx_table(docObj,tableStyle,alertCsv)
    
def add_list_table(docObj,tableStyle,alist):
    docxTable = docObj.add_table(rows=0, cols=1,style=tableStyle)
    for row in alist:
        #print("row:{0}".format(row))
        row_cells = docxTable.add_row().cells
        row_cells[0].text = str(row)

def change_orientation(docObj):
    current_section = docObj.sections[-1]
    new_width, new_height = current_section.page_height, current_section.page_width
    new_section = docObj.add_section(WD_SECTION.NEW_PAGE)
    new_section.orientation = WD_ORIENT.LANDSCAPE
    new_section.page_width = new_width
    new_section.page_height = new_height

    return new_section

def add_footer_image(docObj,image_type):
    current_section = docObj.sections[-1]
    footer = current_section.footer
    footer.is_linked_to_previous = False
    paragraph = footer.paragraphs[0]
    paragraph.paragraph_format.left_indent = -Inches(0.6)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    if image_type == 'landscape':
        run.add_picture('./Config/SMX Footer Logo - Landscape.png')
        current_section.footer_distance = Inches(0.0)
    elif image_type == 'portrait':
        run.add_picture('./Config/SMX Footer Logo - Portrait.png')
        current_section.footer_distance = Inches(0.1)

def replace_run_text(docObj, replaceText, runText):
    body_elements = docObj._body._body
    rs = body_elements.xpath('.//w:r')
        
    for r in rs:
        if(replaceText in r.text):
            r.text = runText
      
def remove_brackets(docObj):
    body_elements = docObj._body._body
    rs = body_elements.xpath('.//w:r')
    
    for r in rs:
        if("}" in r.text or "{" in r.text):
            r.text = ''
    
def get_previous_month():
    # Month and Year
    today = datetime.date.today()
    first = today.replace(day=1)
    lastMonth = first - datetime.timedelta(days=1)
    
    return lastMonth.strftime("%B %Y")

def update_progress(count, total, status=''):
    bar_len = 60
    filled_len = int(round(bar_len * count / float(total)))

    percents = round(100.0 * count / float(total), 1)
    bar = '█' * filled_len + '-' * (bar_len - filled_len)

    sys.stdout.write('%s%s ...%s\r' % (percents, '%', status))
    #sys.stdout.write('[%s] %s%s ...%s\r' % (bar, percents, '%', status))
    sys.stdout.flush()

def insert_customer_name(document,customerName):
    if customerName != "":
        replace_run_text(document, 'CUSTOMER NAME', customerName)
    else:
        errorlog("Customer Name is empty in the script which is required!\n")
        print("Customer Name is empty in the script which is required!\n")
        sys.exit(0)

def insert_customer_env(document,customerEnvProj):
    if customerEnvProj != '':
        replace_run_text(document, 'CUSTOMER ENVIRONMENT/PROJECT', customerEnvProj)
    elif customerEnvProj == '':
        return

def process_servicenow_tables(incidentFile,baseFolder,secOpsTeam):
    debug = False
    #print("Processing incidents file.")
    
    # Import csv file into a pandas dataframe
    csvFileDf = pd.read_csv(incidentFile, usecols = ['number','short_description','comments_and_work_notes','work_notes'])[['number','short_description','comments_and_work_notes','work_notes']]
    #print(Df)
    
    # Create a mask of the data to filter rows that do not contain SecOpsTeam members
    mask = csvFileDf['comments_and_work_notes'].str.contains('|'.join(secOpsTeam),regex=True, na=False) | csvFileDf['work_notes'].str.contains('|'.join(secOpsTeam),regex=True, na=False)
    mergeDf = csvFileDf[mask] # Apply the mask
    # Create new DataFrame and add the header names to the first row
    alertDf = pd.DataFrame([['Number','Name','Comments and Work Notes','Work Notes']], columns=['number','short_description','comments_and_work_notes','work_notes'])
    # Join mergeDf DataFrame to alertDf DataFrame
    alertDf = pd.concat([alertDf, mergeDf], join='inner', ignore_index=True)
    # Remove any Sev 3
    alertDf = alertDf[~alertDf['short_description'].str.contains('(Sev 3)')]

    # Clean up and text
    alertDf['short_description'] = alertDf['short_description'].str.replace('Splunk Alert:\s|Search Alert:\s|Search Results:\s', '', regex=True)
    
    # count total tickets
    totalTickets = len(alertDf.index)
    #print('Total tickets: ' + str(totalTickets))

    # Count total of Severity levels
    #sevDf = alertDf['alertSev'].value_counts().rename_axis('alertSev').reset_index(name='count')

    # Get uniques and counts
    #alertDf = alertDf.value_counts(['short_description','alertId','alertSev','alertDesc']).reset_index(name='count')
    #print(alertDf)
    
    if debug:
        print("DEBUG (process_incidents): alertId={0} alertSev={1} alertDesc={2}".format(alertId,alertSev,alertDesc))
    
    return(totalTickets,alertDf)

def save_document(document,outputDocument,customerName,finalFlag):
    try:
        a = open(outputDocument,'w')
        if not finalFlag:
            print('Saving "' + customerName + ' Monthly Report (' + get_previous_month() + ').docx"') 
        a.close()
        document.save(outputDocument)
        if finalFlag:
            print("\n\nReport generation completed.\n")
    except IOError:
        print('Could not save "' + customerName + ' Monthly Report (' + get_previous_month() + ').docx' + '" The file is open\n')

def findFile(docObj,baseFolder,globPattern):
    # print('debug findFile')
    wildFile = baseFolder + "/*{0}*.*".format(globPattern)
    foundFile = glob.glob(wildFile)
    if foundFile and len(foundFile) == 1:
        # return if found and valid
        #print('foundFile = ' + foundFile[0])
        return foundFile[0]
        
    else:
        errorlog("Error locating " + foundFile[0] + "file in data folder.\nGlob result was: {0}\n".format(foundFile))
        return
