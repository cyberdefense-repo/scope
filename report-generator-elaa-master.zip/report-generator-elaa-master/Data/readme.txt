Add your data such as incident.csv to this folder.
Add your alert names in a file called Active_Alerts.csv