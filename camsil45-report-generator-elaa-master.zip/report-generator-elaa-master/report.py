from reportcore import *

#######################
# Clear the error log #
#######################
errorhandle = open(".\error.log", "w")
errorhandle.close()


#################################
# Customer specific information #
#################################

# This variable should not be changed unless your filename is different
incidentsFile = './Data/incident.csv'

# This list is used to collect records from ServiceNow based on work logs
#secOpsTeam = ['Currao, Joseph','Denton, Matthew H.','Harris, James','Izen, Thomas','Khan, Andleeb','Locke, Timothy T.','Mendoza, Alfonso','Mustafa, Ramisa','Paquin, Joseph','Quick, Brian E','Sheldon, Michael']

# The following two variables should match your filenames
activeAlerts = 'Active_Alerts.csv' # Ex. Live_Alerts.csv
ing002Filename = 'ING002.csv' # Ex. ING002.csv

# The following three variables should match your customer preference. 


customerEnvProj = '' # This variable is optional and can be left with empty quotes

# Set these flags to True if ticket and alert addendums are needed. Else set it to False.
tktAddFlag = False # This is the Ticket Addendum. Ex. True or False 
alertAddFlag = False # This is the Alert Addendum. Ex. True or False

# Do not change the following variables
baseFolder = './Data'
inputDocument = './config/MasterTemplateV1.5.docx'
inputAlertAddDoc = './config/AlertAddendumV1.0.docx'
inputTktAddDoc = './config/TicketAddendumV1.0.docx'
outputDocument = './' + customerName + ' Monthly Report (' + get_previous_month() + ').docx'
outputImage = './ingest-chart.png'
finaloutputDocument = '\\' + customerName + ' Monthly Report (' + get_previous_month() + ').docx'


################################
# START OF DOCUMENT GENERATION #
################################
document = docx.Document(inputDocument)

# Customer Title #
insert_customer_name(document,customerName)

# Customer Environment/Project #
insert_customer_env(document,customerEnvProj)

# Month and Year
replace_run_text(document, 'Month Year',' ' + get_previous_month())
remove_brackets(document)

# Introduction #
document.add_heading('Introduction',level=1)
document.add_heading('Purpose',level=2)
document.add_paragraph('This report summarizes the state of the environment for ' + customerAbreviation + ' and highlights key findings from data analysed in the past month. The objective is to highlight any issues, provide recommendations, and improve tuning of the overall system.')
document.add_heading('Intended Audience',level=2)
document.add_paragraph('The intended audience of this report is any security stakeholders at ' + customerAbreviation + ', specifically the Security Leads and those that have decision-making roles.')

# Executive Summary #
document.add_heading('Executive Summary',level=1)
document.add_heading('Current Activities',level=2)
document.add_paragraph('Continuous monitoring of AWS environments.', style='Bullet List')
document.add_paragraph('24/7 GuardDuty threat detection intelligence with cloud-based integrated analysis.', style='Bullet List')
document.add_paragraph('Triage of alerts for analysis, false positive tuning, ticketing and notification as appropriate.', style='Bullet List')
document.add_paragraph('Ongoing management of Trend Micro Deep Security endpoint protection.', style='Bullet List')

document.add_heading('Recommendations',level=2)
document.add_paragraph('No recommendations at this time.', style='Bullet List')
document.add_paragraph('list', style='Bullet List')

# Add a page break
document.add_page_break()

# Threat Activity #
document.add_heading('Threat Status',level=1)
document.add_paragraph('This section details notable threat hunting and security tool visibility to provide situational awareness.')

## Hunting
document.add_heading('Notable Threat Hunting Activities',level=2)
document.add_paragraph('Continuous Hunting for Anomalous Behavior in IAM, EC2, RDS, S3, Lambda, etc.', style='Bullet List')
document.add_paragraph('Malicious IP Detection.', style='Bullet List')
document.add_paragraph('Excessive Failed Logins.', style='Bullet List')
document.add_paragraph('Suspicious Defensive Evasion Measures.', style='Bullet List')
document.add_paragraph('Malware Based Behavior.', style='Bullet List')
document.add_paragraph('Recon/Unusual API Requests.', style='Bullet List')
document.add_paragraph('Unusual Protocol Usage.', style='Bullet List')
document.add_paragraph('Bot Activity and Suspicious UserAgent Strings.', style='Bullet List')
document.add_paragraph('DNS Tunneling.', style='Bullet List')
document.add_paragraph('DNS Based Command and Control (C2).', style='Bullet List')
document.add_paragraph('Unauthorzed Account Creations.', style='Bullet List')
document.add_paragraph('Unauthorized Group Creations.', style='Bullet List')
document.add_paragraph('Unauthorized Accounts Re-Enabled.', style='Bullet List')
document.add_paragraph('Password Resets by Unauthorized Parties.', style='Bullet List')
document.add_paragraph('Interactive Service Account Login.', style='Bullet List')
document.add_paragraph('Unusual SSM RunDoc Creations.', style='Bullet List')
document.add_paragraph('Unusual SSM RunDoc Executions.', style='Bullet List')
document.add_paragraph('Unusual Session Manager Activity.', style='Bullet List')
document.add_paragraph('Unauthorized Administration Activity.', style='Bullet List')
document.add_paragraph('Post-Exploitation Recon.', style='Bullet List')
document.add_paragraph('Unauthorized Privilege Escalation Attempts.', style='Bullet List')
document.add_paragraph('')
document.add_paragraph('')


## Endpoint Agent
document.add_heading('Trend Micro Deep Security',level=2)

### Anti-Malware
document.add_heading('Anti-Malware Module',level=3)
document.add_paragraph('The Trend Micro Deep Security Anti-Malware Module implements signature, machine learning, file reputation and behavioural detection methods.')
insert_findings_paragraph(document,'No Malicious Trend Micro Deep Security Anti-Malware events found during this reporting period.')

### IPS
document.add_heading('Intrusion Prevention',level=3)
document.add_paragraph('The Trend Micro Deep Security Intrusion Prevention Module implement detection and/or prevention of network-based attacks that are identified by vendor IPS rules.')
insert_findings_paragraph(document,'No Malicious Trend Micro Deep Security Intrusion Prevention events found during this reporting period.')

### Firewall
document.add_heading('Firewall',level=3)
document.add_paragraph('The Trend Micro Deep Security Firewall Module implements stateful inspection of network traffic. The firewall events were reviewed for noteworthy activity.')
insert_findings_paragraph(document,'No Malicious Trend Micro Deep Security Firewall events found during this reporting period.')

### Integrity Monitoring
document.add_heading('Integrity Monitoring',level=3)
document.add_paragraph('The Trend Micro Deep Security File Integrity Module implements system change monitoring based on vendor rules and customer application file monitoring rules. The below table shows the activity observed during the reporting period.')
insert_findings_paragraph(document,'No Malicious Trend Micro Deep Security File Integrity events found during this reporting period.')
document.add_paragraph('')

## AWS Cloud Native Monitoring
document.add_heading('AWS Cloud Native Monitoring',level=2)

## AWS Cloud Native Monitoring Summary
document.add_heading('AWS Cloud Native Monitoring Protection',level=3)
document.add_paragraph('The following AWS Cloud services are also monitored to verify security best practices and standards are being applied. (AWS Identity and Access Management (IAM), AWS Config, AWS CloudTrail, AWS CloudWatch, and AWS Simple Storage Service (S3)')

### Identity and Access Management (IAM) 
document.add_heading('Identity and Access Management (IAM)',level=3)
document.add_paragraph('AWS root account usage, IAM policy changes, security group changes, AWS console login failures, and multi-factor authentication (MFA) usage.')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

### AWSConfig
document.add_heading('AWS Config',level=3)
document.add_paragraph('AWSConfig configuration changes')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

### AWSCloudTrail
document.add_heading('AWS CloudTrail',level=3)
document.add_paragraph('AWSCloudTrail configuration changes')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

### AWSCloudWatch
document.add_heading('AWS CloudWatch',level=3)
document.add_paragraph('AWSCloudWatch configuration changes')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

### AWS S3
document.add_heading('AWS Simple Storage Service (S3)',level=3)
document.add_paragraph('AWS S3 configuration changes like S3 bucket-policy changes')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

### AWS Networking
document.add_heading('AWS Networking',level=3)
document.add_paragraph('AWS Networking configuration changes like NACL changes, network-gateway changes, route-table changes, and VPC changes.')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

### AWS KMS
document.add_heading('AWS Key Management Service (KMS)',level=3)
document.add_paragraph('AWS KMS Customer Master Key (CMK) is disabled or KMS deletion scheduled changes.')
insert_findings_paragraph(document,'No Malicious Findings during this reporting period.')

# Add a page break
document.add_page_break()

## AWS Cloud Native Monitoring
document.add_heading('AWS - EC2 Instance Port and Process Monitoring',level=2)
document.add_heading('AWS - EC2 Top Talkers by Destination Port',level=3)
pbttimage = 'pbtoptalkers.png'
document.add_picture(pbttimage,width=Inches(7), height=Inches(7))

# Add a page break
#document.add_page_break()
document.add_heading('AWS - EC2 DNS Response Summary',level=3)
pbttimage = 'pbdnsresp.png'
document.add_picture(pbttimage,width=Inches(6), height=Inches(6))

document.add_heading('AWS - EC2 DNS Answers Summary',level=3)
pbttimage = 'pbdnsanswers.png'
document.add_picture(pbttimage,width=Inches(7), height=Inches(6))

document.add_page_break()
document.add_heading('AWS EC2 -  Linux Account Summary',level=3)
pbttimage = 'pblinuxlogins.png'
document.add_picture(pbttimage,width=Inches(7), height=Inches(6))

document.add_page_break()
document.add_heading('AWS EC2 -  Linux Process Summary',level=3)
pbttimage = 'pblinuxprocs.png'
document.add_picture(pbttimage,width=Inches(6), height=Inches(6))

# Ticket Summary #
document.add_page_break()
document.add_heading('Ticket Summary',level=1)
document.add_paragraph('When an alert is triggered in the ' + customerAbreviation + ' SIEM tool environment, an email notification is automatically sent to the Smartronix Threat Analytics Team for action.  Email notifications trigger ticket creation in the Smartronix ServiceNow ticketing system.  Event tickets are used to track and archive security events and can be accessed via the ServiceNow ticketing system.  Events are classified into the separate data sources from which the SIEM tool ingests log data.  Event tickets are further classified by the severity level of the Event.')
print("Processing incidents file\n")
insert_ticket_summary(document,incidentsFile,baseFolder)

# Ticket Details #
change_orientation(document)
insert_ticket_details(document,incidentsFile,baseFolder,inputAlertAddDoc,alertAddFlag)
change_orientation(document)

# Ticket Addendum #
insert_ticket_addendum(customerName,incidentsFile,baseFolder,inputTktAddDoc,get_previous_month(),tktAddFlag)

# Log Ingestion #

document.add_heading('Log Ingestion',level=1)
document.add_paragraph('This section is for the log ingest rate for the previous month. The data is presented in a chart and table format.')

(gbCount,dailyAvg) = insert_chart_ingest(document,baseFolder,'ING001',outputImage,3,6)
insert_ingest_calendar(document,baseFolder,'ING001')
document.add_heading('Monthly Ingestion Totals',level=2)
document.add_paragraph('Total Ingestion for the Month: ' + gbCount + ' GB', style='Bullet List')
document.add_paragraph('Daily Average for the Month: ' + dailyAvg + ' GB', style='Bullet List')
document.add_heading('Monthly Log Ingestion By Sourcetype',level=2)
insert_csv_table(document,baseFolder + '/' + ing002Filename)


# Active Alerts #
document.add_page_break()
document.add_heading('Active Alerts',level=1)
insert_active_alerts(document,baseFolder + '/' + activeAlerts, baseFolder)


#######################
# Save final document #
#######################
#save_document(document,outputDocument,customerName,False)
save_document(document,outputDocument,customerName,False)

cwd = os.getcwd() + finaloutputDocument
document2 = docx.Document(cwd)
save_document(document2,outputDocument,customerName,True)

exit()
